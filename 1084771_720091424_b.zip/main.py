import reporting
import monitoring
import intelligence

def main_menu():
    """Your documentation goes here"""
    print("R - Pollution Reporting\nI - Mobility Intelligence\nM - Real-time Monitoring \nA - About\nQ - Quit\n")


    #take input into different places
    ipt = input('Choose an option: ')
    if ipt.lower() ==  'r':
        print("\033c")
        reporting_menu()
    elif ipt.lower() == 'i':
        print("\033c")
        intelligence_menu()
    elif ipt.lower() == 'm':
        print("\033c")
        monitoring_menu()
    elif ipt.lower() == 'a':
        print("\033c")
        about()
    elif ipt.lower() == 'q':
        print("\033c")
        quit()
    else:
        print("\033c")
        print('Invalid input\n')
        main_menu()
            

def monitoring_menu():
    site_code = ''
    species_code = ''

    
    #Monitoring Choose Station
    print('0 - Marylebone Road\n1 - N. Kensington(Not working)\n2 - Harlington(Not working)\nm - menu\n')
    rs = input('\nChoose a Reporting station: ')
    print("\033c")
    if rs == '0':
        rsvalue = 'Marylebone Road'
        file = 'Pollution-London Marylebone Road.csv'
        site_code = 'MY1'
    elif rs == '1':
        rsvalue = 'Marylebone Road'
        file = 'Pollution-London N Kensington.csv'
        site_coe = 'KC1'
    elif rs == '2':
        rsvalue = 'N. Kensington'
        file = 'Pollution-London Harlington.csv'
        site_coe = 'HRL'
    elif rs.lower() == 'm':
        print("\033c")
        main_menu()
    else:
        print("\033c")
        print('\nInvalid Input\n')
        monitoring_menu()


    #Monitoring Choose pm value
    print("\033c")
    print('0 - No\n1 - pm10(Not working)\n2 - pm25(Not working)\n')
    pinput = input("\nChoose a pollutant: ")
    if pinput == '0':
        pvalue = 'Nitric Oxide'
        species_code = 'NO'
    elif pinput == '1':
        pvalue = 'pm10'
        species_code = 'PM10'
    elif pinput == '2':
        pvalue = 'pm25'
        species_code = 'PM25'
    elif rs.lower() == 'm':
        main_menu()
    else:
        print("\033c")
        print('\nInvalid Input\n')
        monitoring_menu()

        
    #Monitoring Choose reported data mode
    print("\033c")
    print('0 - Daily Average\n1 - Daily Median\n2 - Monthly Averages\n3 - Peak Hour Today\n4 - Real Time Line Graph\nm - menu\n')
    minput = input('\nChoose a reported data: ')
    if minput == '0':
        mvalue = 'Daily Average'
    elif minput == '1':
        mvalue = 'Daily Median'
        print('done')
    elif minput == '2':
        mvalue = 'Monthly Averages'
    elif minput == '3':
        mvalue = 'Peak Hour Today'
    elif minput == '4':
        mvalue = 'Real Time Line Graph'
    elif rs.lower() == 'm':
        main_menu()
    else:
        print("\033c")
        print('\nInvalid Input\n')
        monitoring_menu()
    
    
    #Monitoring Output the result
    if True:
        print("\033c")
        if minput == '0':
            try:
                print(f"This is the list of {rsvalue}'s {mvalue} {pvalue} pollution:\n")
                print(site_code,species_code)
                print(monitoring.current_day_average(site_code,species_code))
            except:
                print("\033c")
                print('Something is wrong, returning to main menu')
                main_menu()
        if minput == '1':
            try:
                print(f"This is the list of {rsvalue}'s {mvalue} {pvalue} pollution:\n")
                print(monitoring.current_day_median(site_code,species_code))
            except:
                print("\033c")
                print('Something is wrong, returning to main menu')
                main_menu()
        if minput == '2':
            try:
                print(f"This is the list of {rsvalue}'s {mvalue} {pvalue} pollution:\n")
                print(monitoring.current_month_average(site_code,species_code))
            except:
                print("\033c")
                print('Something is wrong, returning to main menu')
                main_menu()
        if minput == '3':
            try:
                print(f"This is the list of {rsvalue}'s {mvalue} {pvalue} pollution:\n")
                print(monitoring.peak_hour_today(site_code,species_code))
            except:
                print("\033c")
                print('Something is wrong, returning to main menu')
                main_menu()
        if minput == '4':
            try:
                print(f"This is the line graph of {rsvalue}'s {mvalue} {pvalue} pollution:\n")
                print("Don't resize the treminal window or the graph may be distored")
                monitoring.data_to_graph(site_code,species_code)
            except:
                print("\033c")
                print('Something is wrong, returning to main menu')
                main_menu()
        try:
            inpt = input("\nPress m to return to main menu: ")
            if inpt.lower() == 'm':
                print("\033c")
                main_menu()
            else:
                print("\033c")
                print("Invalid input")
                monitoring_menu
        except:
            print("\033c")
            print('Something is wrong, returning to main menu')
            main_menu()



def intelligence_menu():
    try:
        print("\033c")
        print("Mobility Intelligence")
        reding = intelligence.find_red_pixels('data/map.png')
        print("\033c")
        print("Scanning Roads...")
        intelligence.find_cyan_pixels('data/map.png')
        print("\033c")
        print("Scanning Roads...")
        imgs,dict =intelligence.detect_connected_components(reding)
        print("\033c")
        print("Scanning For Connected Roads...")
        intelligence.detect_connected_components_sorted(imgs,dict)
        print("Sorting Connected Roads...")
        print("\033c")
        print("Files For Walkability Is Generated")
        ipt = 0
        while str(ipt).lower() != "m":
            ipt = input('M - main menu: ')
        if ipt.lower() == "m":
            print("\033c")
            main_menu()
    except:
        print("\033c")
        print('Something is wrong, returning to main menu')
        main_menu()


def reporting_menu():
    rsvalue = 'Null'#Name of station
    mvalue = 'Null'#Name of mode
    pvalue = 'Null'#Name of pollutant
    """0 - Harlington, 1 - Marylebone, 2 - Kensington"""
    """0 - no 1- pm10, 2 - pm25"""
    """0 - date, 1- time"""

    #Choose Station
    print('0 - Harlington\n1 - Marylebone\n2 - N. Kensingtonm\nm - menu\n')
    rs = input('\nChoose a Reporting station: ')
    print("\033c")
    if rs == '2':
        rsvalue = 'N. Kensington Road'
        rs = 'KC1'
    elif rs == '1':
        rsvalue = 'Marylebone Road'
        rs = 'MY1'
    elif rs == '0':
        rsvalue = 'Harlington Road'
        rs = 'HRL'
    elif rs.lower() == 'm':
        print("\033c")
        main_menu()
    else:
        print("\033c")
        print('\nInvalid Input\n')
        reporting_menu()


    #Choose pm value
    print("\033c")
    print('0 - No\n1 - pm10\n2 - pm25\n')
    pinput = input("\nChoose a pollutant: ")
    if pinput == '0':
        pvalue = 'NO'
    elif pinput == '1':
        pvalue = 'PM10'
    elif pinput == '2':
        pvalue = 'PM25'
    elif rs.lower() == 'm':
        print("\033c")
        main_menu()
    else:
        print("\033c")
        print('\nInvalid Input\n')
        reporting_menu()

        
    #Choose reported data mode
    print("\033c")
    print('0 - Daily Average\n1 - Daily Median\n2 - Hourly Average\n3 - Monthly Averages\n4 - Peak Hour Date\nm - menu\n')
    minput = input('\nChoose a reported data: ')
    if minput == '0':
        mvalue = 'Daily Average'
    elif minput == '1':
        mvalue = 'Daily Median'
    elif minput == '2':
        mvalue = 'Hourly Average'
    elif minput == '3':
        mvalue = 'Monthly Averages'
    elif minput == '4':
        mvalue = 'Peak Hour Date'
    elif rs.lower() == 'm':
        print("\033c")
        main_menu()
    else:
        print("\033c")
        print('\nInvalid Input\n')
        reporting_menu()
    
    
    #Output the result
    if True: #placeholder
        print("\033c")
        if minput == '0':
            if True:
                print(f"This is the list of {rsvalue}'s {mvalue} {pvalue} pollution:\n")
                print(reporting.daily_average('data',rs,pvalue))
                print('\nMissing data:'+ str(reporting.count_missing_data('data',rs,pvalue)))
            else:
                print("\033c")
                print('Something is wrong, returning to main menu')
                main_menu()
        if minput == '1':
            try:
                print(f"This is the list of {rsvalue}'s {mvalue} {pvalue} pollution:\n")
                print(reporting.daily_median('data',rs,pvalue))
                print('\nMissing data: '+ str(reporting.count_missing_data('data',rs,pvalue)))
            except:
                print("\033c")
                print('Something is wrong, returning to main menu')
                main_menu()
        if minput == '2':
            try:
                print(f"This is the list of {rsvalue}'s {mvalue} {pvalue} pollution:\n")
                print(reporting.hourly_average('data',rs,pvalue))
                print('\nMissing data: '+ str(reporting.count_missing_data('data',rs,pvalue)))
            except:
                print("\033c")
                print('Something is wrong, returning to main menu')
                main_menu()
        if minput == '3':
            try:
                print(f"This is the list of {rsvalue}'s {mvalue} {pvalue} pollution:\n")
                print(reporting.monthly_average('data',rs,pvalue))
                print('\nMissing data: '+ str(reporting.count_missing_data('data',rs,pvalue)))
            except:
                print("\033c")
                print('Something is wrong, returning to main menu')
                main_menu()
        if minput == '4':
            try:
                phd = input("Input a date for peak hour(YYYY-MM-DD): ")
                print(f"This is the value of {rsvalue}'s {phd} {pvalue} pollution:\n")
                print(reporting.peak_hour_date('data',phd,rs,pvalue))
            except:
                print("\033c")
                print('Something is wrong, returning to main menu')
                main_menu()
        try:
            inpt = input("\nPress m to return to main menu: ")
            if inpt.lower() == 'm':
                print("\033c")
                main_menu()
            else:
                print("\033c")
                print("Invalid input")
                reporting_menu()
        except:
            print("\033c")
            print('Something is wrong, returning to main menu')
            main_menu()


def about():
    """Your documentation goes here"""
    print("\033c")
    print('ECM1400,018197')
    try:
        ipt = input('Press m to return to menu: ')
        if ipt.lower() == 'm':
            main_menu()
            print("\033c")
        else:       
            print("\033c")
            print('Invalid Input')
            about()
    except:
        print("\033c")
        print('Something is wrong, returning to main menu')
        main_menu()


def quit():
    """Your documentation goes here"""
    try:
        ipt = input('Are you sure you want to quit? (y/N): ')
        if ipt.lower() == 'y':
            print("\033c")
            print('Quitting')
        else:
            main_menu()
    except:
        main_menu()

        
if __name__ == "__main__":
    print("\033c")
    main_menu()
