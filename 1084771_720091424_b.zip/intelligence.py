# This is a template. 
# You should modify the functions below to match
# the signatures determined by the project specification
import numpy as np
from skimage import io
import utils

def find_red_pixels(map_filename):
    #input file name and output an image
    """Your documentation goes here"""
    map_filename = io.imread(map_filename)
    newimage = []
    for row in map_filename: 
        rowtemp = []
        for pixel in row:
            if 100 <= pixel[0] <= 255 and 0 <= pixel[1] <= 50 and 0 <= pixel[2] <= 50:
                rowtemp.append([255,255,255])
            else:
                rowtemp.append([0,0,0])
        newimage.append(rowtemp)
    newimage = np.array(newimage)
    io.imsave('map-red-pixels.jpg',newimage.astype(np.uint8))
    return newimage


def find_cyan_pixels(map_filename):
    #Input file name and output an image
    map_filename = io.imread(map_filename)
    newimage = []
    for row in map_filename: 
        rowtemp = []
        for pixel in row:
            if 0 <= pixel[0] <= 50 and 100 <= pixel[1] <=255 and 100 <= pixel[2] <= 255:
                rowtemp.append([255,255,255])
            else:
                rowtemp.append([0,0,0])
        newimage.append(rowtemp)
    newimage = np.array(newimage)
    io.imsave('map-cyan-pixel.jpg',newimage.astype(np.uint8))
    return newimage


def detect_connected_components(img):
    #Input an image and return marked image and a dictionary for finding corresponding components and output a text file
    arr = utils.img_to_bin(img)#turn the image into binary ndarray(1,0)
    newdict = {}
    row,col = arr.shape
    Q = []
    mark = np.zeros(arr.shape)#create an unmarked ndarray
    markcount = 1#different connected graph has differnt markcount value
    for x in range(0,row):#scanning the array
        for y in range(0,col):
            pixcount = 0 #count number of pixel in each mark
            if arr[x,y] == 1 and mark[x,y] == 0:     
                pixcount += 1      
                mark[x,y] = markcount
                Q.append([x,y])
                while len(Q) > 0:
                    m,n =Q.pop(0)
                    neighbours = utils.pixel_neighbours(arr,[m,n])
                    for coords in neighbours:
                        s,t = coords
                        if arr[s,t] == 1 and mark[s,t] == 0:
                            mark[s,t] = markcount
                            pixcount += 1
                            Q.append([s,t])
                newdict[markcount] = pixcount #append markcount into the dictionary
                markcount += 1
    #create into text folder
    text = '' 
    for keys in newdict:
        text += f"Connected Component {keys}, number of pixels = {newdict[keys]}\n"
    text += f'Total number of connected components {len(newdict)}'
    with open('cc-output-2a.txt', 'w') as f:
            f.write(str(text))
    mark = np.array(mark)
    newdict.pop(0, None)
    return mark,newdict


def detect_connected_components_sorted(MARK,Dict):
    #Input marked value and dictionary and output the image with the image with 2 largest connected component and text file
    """Your documentation goes here"""
    
    lists = Dict
    sort = sorted(lists.items(), key=lambda item: item[1],reverse=True) #turn dictionary intor a sorted list
    text = ''
    for list in sort:
        text += f"Connected Component {list[0]}, number of pixels = {list[1]}\n"
    text += f'Total number of connected components {len(Dict)}'
    #extract the top component marknumber into component and component1
    component, pixels = sort[0] 
    component1, pixels1 = sort[1]
    IMG = []
    IMG1 = []
    #isolate the top two image from component marker
    for rows in MARK:
        rowtemp = []
        for pixel in rows:
            if pixel == int(component):
                rowtemp.append(1)
            else:
                rowtemp.append(0)
        IMG.append(rowtemp)
    for rows in MARK:
        rowtemp = []
        for pixel in rows:
            if pixel == int(component1):
                rowtemp.append(1)
            else:
                rowtemp.append(0)
        IMG1.append(rowtemp)
    #convert the Bin ing to Image value
    IMG = utils.bin_to_img(np.array(IMG))
    IMG1 = utils.bin_to_img(np.array(IMG1))
    io.imsave('cc-top-1.jpg',IMG.astype(np.uint8))
    io.imsave('cc-top-2.jpg',IMG1.astype(np.uint8))
    
    #turn the text into text file
    with open('cc-output-2b.txt', 'w') as f:
            f.write(str(text))




    
    
        
