import requests
import datetime
import numpy as np


def get_live_data_from_api(site_code,species_code,start_date=None,end_date=None):
    """
    Return data from the LondonAir API using its AirQuality API. 
    
    *** This function is provided as an example of how to retrieve data from the API. ***
    It requires the `requests` library which needs to be installed. 
    In order to use this function you first have to install the `requests` library.
    This code is provided as-is. 
    """
    start_date = datetime.date.today() - datetime.timedelta(days=1) if start_date is None else start_date
    end_date = datetime.date.today() + datetime.timedelta(days=1) if end_date is None else end_date
    
    
    endpoint = "https://api.erg.ic.ac.uk/AirQuality/Data/SiteSpecies/SiteCode={site_code}/SpeciesCode={species_code}/StartDate={start_date}/EndDate={end_date}/Json"
   
    url = endpoint.format(
        site_code = site_code,
        species_code = species_code,
        start_date = start_date,
        end_date = end_date
    )
    
    res = requests.get(url)
    return res.json()


def json_to_dict(apilist):
    """Your documentation goes here"""
    nlist = []
    ndict = {}
    for dict in apilist.values():
        for dicts in dict["Data"]:
            templist = []
            tempvalue = 0
            for value in dicts.values():
                templist.append(value)
            nlist.append(templist)
    for lists in nlist:
        if lists[0] not in ndict:
            ndict[lists[0]]=lists[1]
    return ndict


def current_day_average(site_code,species_code):
    """Your documentation goes here"""
    start_date = datetime.date.today()
    end_date = start_date + datetime.timedelta(days=1)
    dict = json_to_dict(get_live_data_from_api(site_code,species_code,start_date,end_date))
    count = 0
    sum = float(0)
    for values in dict.values():
        if values != '':
            sum += float(values)
            count += 1
    if sum == 0:
        return sum
    else:
        return round(sum/count,3)


def current_day_median(site_code,species_code):
    """Your documentation goes here"""
    start_date = datetime.date.today()
    end_date = start_date + datetime.timedelta(days=1)
    dict = json_to_dict(get_live_data_from_api(site_code,species_code,start_date,end_date))
    L = []
    for values in dict.values():
        if values != '':
            L.append(values)
    L1 = []
    for item in L:
        L1.append(float(item))
    L1 = np.median(L1)
    return L1


def current_month_average(site_code,species_code):
    """Your documentation goes here"""
    month = datetime.date.today().month
    year = datetime.date.today().year
    this_month = str(year) + '-' + str(month) + '-01'
    start_date = this_month
    end_date = datetime.date.today() + datetime.timedelta(days=1)
    dict = json_to_dict(get_live_data_from_api(site_code,species_code,start_date,end_date))
    count = 0
    sum = float(0)
    for values in dict.values():
        if values != '':
            sum += float(values)
            count += 1
    if sum == 0:
        return sum
    else:
        return round(sum/count,3)


def peak_hour_today(site_code,species_code):
    start_date = datetime.date.today()
    end_date = start_date + datetime.timedelta(days=1)
    dict = json_to_dict(get_live_data_from_api(site_code,species_code,start_date,end_date))
    max = 0.0
    maxdate = ''
    for values in dict:
        if dict[values] != '':
            if float(dict[values]) > float(max):
                max = float(dict[values])
                maxdate = values[11:-1]
    return max,maxdate


def data_to_graph(site_code,species_code):
    i = get_live_data_from_api(site_code,species_code)
    '''if getting data fails , remove the hastag from next line'''
    #i = {'RawAQData': {'@SiteCode': 'MY1', '@SpeciesCode': 'NO', 'Data': [{'@MeasurementDateGMT': '2022-12-13 00:00:00', '@Value': '7'}, {'@MeasurementDateGMT': '2022-12-13 01:00:00', '@Value': '6.5'}, {'@MeasurementDateGMT': '2022-12-13 02:00:00', '@Value': '4.7'}, {'@MeasurementDateGMT': '2022-12-13 03:00:00', '@Value': '5'}, {'@MeasurementDateGMT': '2022-12-13 04:00:00', '@Value': '6'}, {'@MeasurementDateGMT': '2022-12-13 05:00:00', '@Value': '7.4'}, {'@MeasurementDateGMT': '2022-12-13 06:00:00', '@Value': '16'}, {'@MeasurementDateGMT': '2022-12-13 07:00:00', '@Value': '34.3'}, {'@MeasurementDateGMT': '2022-12-13 08:00:00', '@Value': '101.1'}, {'@MeasurementDateGMT': '2022-12-13 09:00:00', '@Value': '100.3'}, {'@MeasurementDateGMT': '2022-12-13 10:00:00', '@Value': '54.8'}, {'@MeasurementDateGMT': '2022-12-13 11:00:00', '@Value': '55.2'}, {'@MeasurementDateGMT': '2022-12-13 12:00:00', '@Value': '68.3'}, {'@MeasurementDateGMT': '2022-12-13 13:00:00', '@Value': '58.9'}, {'@MeasurementDateGMT': '2022-12-13 14:00:00', '@Value': '64.6'}, {'@MeasurementDateGMT': '2022-12-13 15:00:00', '@Value': '66.1'}, {'@MeasurementDateGMT': '2022-12-13 16:00:00', '@Value': '72.3'}, {'@MeasurementDateGMT': '2022-12-13 17:00:00', '@Value': '49.6'}, {'@MeasurementDateGMT': '2022-12-13 18:00:00', '@Value': '49.5'}, {'@MeasurementDateGMT': '2022-12-13 19:00:00', '@Value': '31.5'}, {'@MeasurementDateGMT': '2022-12-13 20:00:00', '@Value': '32.2'}, {'@MeasurementDateGMT': '2022-12-13 21:00:00', '@Value': '28.1'}, {'@MeasurementDateGMT': '2022-12-13 22:00:00', '@Value': '10.4'}, {'@MeasurementDateGMT': '2022-12-13 23:00:00', '@Value': '11.2'}, {'@MeasurementDateGMT': '2022-12-14 00:00:00', '@Value': '11.4'}, {'@MeasurementDateGMT': '2022-12-14 01:00:00', '@Value': '7.2'}, {'@MeasurementDateGMT': '2022-12-14 02:00:00', '@Value': '3.7'}, {'@MeasurementDateGMT': '2022-12-14 03:00:00', '@Value': '2.4'}, {'@MeasurementDateGMT': '2022-12-14 04:00:00', '@Value': '1.9'}, {'@MeasurementDateGMT': '2022-12-14 05:00:00', '@Value': '3.3'}, {'@MeasurementDateGMT': '2022-12-14 06:00:00', '@Value': '6.7'}, {'@MeasurementDateGMT': '2022-12-14 07:00:00', '@Value': '7.8'}, {'@MeasurementDateGMT': '2022-12-14 08:00:00', '@Value': '11'}, {'@MeasurementDateGMT': '2022-12-14 09:00:00', '@Value': '12.5'}, {'@MeasurementDateGMT': '2022-12-14 10:00:00', '@Value': '19.1'}, {'@MeasurementDateGMT': '2022-12-14 11:00:00', '@Value': ''}]}}
    dict = json_to_dict(i)
    tlist = []#time list
    vlist = []#value list
    # convert from a dictionary to time list and value list

    date = ''
    for keys in dict:
        tlist.append(keys[11:13])
        date = keys[0:10]
    for keys in dict.values():
        vlist.append(keys)
    end = 0
    for values in dict:
        end = values
    if end == '':
        tlist = tlist[-26:-2]
        vlist = vlist[-26:-2]
    else:
        tlist = tlist[-25:-1]
        vlist = vlist[-25:-1]
    glist = []#empty graph graph list



    #if string is empty or exceeds 1000
    for value in range(0,len(vlist)):
        if vlist[value] == '':
            vlist[value] = 0
        if float(vlist[value]) >= 1000:
            vlist[value]= 980


    #Finding the max value of data
    vmax = 0
    for values in vlist:
        if values != '':
            if float(values) > float(vmax):
                vmax = float(values)
        
            
    #Converting max value into graphical value
    if vmax == 0:
        vmax = 20
    elif vmax > round_to_multiple(vmax,20):
        vmax = (round_to_multiple(vmax,20)+20)
    else:
        vmax = round_to_multiple(vmax,20)


    #Fill data in value list:
    temp = 'temp'
    tvlist = []
    for data in vlist:
        if temp != 'temp':
            sum = float(temp)
            for x in range(1,5):
                sum += ((float(data)-float(temp))/5)
                tvlist.append((round(sum,1)))
            temp = data
            tvlist.append(temp)
        else:
            temp = data
            tvlist.append(temp)
    vlist = tvlist


    #Empty graph construction
    str1 = str(vmax).zfill(3)+ '+'
    for x in range(1,24):
        str1 += '+----'
    str1 += '+---++'
    glist.append([str1])
    strempty = '   |'
    for x in range(1,5*24):
        strempty += ' '
    strempty += ' |'
    glist.append([strempty])
    #middle row
    for i in range(1,10):
        str1 = str(int(vmax-vmax/10*i)).zfill(3) + '+'
        for x in range(1,5*24):
            str1 += ' '
        str1 += '++'
        glist.append([str1])
        strempty = '   |'
        for x in range(1,5*24):
            strempty += ' '
        strempty += ' |'
        glist.append([strempty])
    #last row
    str1 = str('000') + '+'
    for x in range(1,24):
        str1 += '+----'
    str1 += '+---++'
    glist.append([str1])
    #time row
    bstring = ' '
    for i in tlist:
        bstring +=  '   ' + str(i).zfill(2) 
    bstring += '    '
    glist.append([bstring])


    #Converting graph to 2D numpy array
    nlist = []
    for list in glist:
        for string in list:
            clist = []
            for i in range(0,len(string)):
                clist.append(string[i])
        nlist.append(clist)
    nlist = np.array(nlist)
    


    #Inserting values into numpy array
    row,col = nlist.shape
    for i in range(0,len(vlist)):
        #rounding value into incriments of 20
        if float(vlist[i])  >= round_to_multiple(round(float(vlist[i])),vmax/(10*2)) + vmax/(10*4):
            j = round_to_multiple(round(float(vlist[i])),vmax/(10*2)) + vmax/(10*4)
        else:
            j = round_to_multiple(round(float(vlist[i])),vmax/(10*2))
        #Inserting values into numpy array
        nlist[int((vmax-j)/(vmax/20)),int(4+i)] = '*'


    #Converting numpy array into graph
    print('\n\n')
    print('Pollution Value')
    string = ''
    for lists in nlist:
        for charaters in lists:
            string += charaters
        string += '\n'
    print(string.strip())
    tstring = ''
    date = str(date)
    tstringe = date + ' ' + 'Time'
    for i in range(0,len(str1)-len(tstringe)-len(tstring)):
        tstring += ' '
    tstring += tstringe
    print(tstring)


def round_to_multiple(number, multiple):
    if number > 0:
        return multiple * round(number / multiple)
    else:
        return 0
    
if __name__ == "__main__":
    data_to_graph('MY1','NO')