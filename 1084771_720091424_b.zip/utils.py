import numpy as np
from skimage import io

def sumvalues(values):
    """Your documentation goes here"""    
    sum = 0
    for n in values:
        if n != 'No data':
            sum += float(n)
    return sum

def maxvalue(values):
    """Your documentation goes here"""    
    x = 0
    for n in values:
        if n != 'No data':
            if float(n) > x:
                x = float(n)
    return x


def minvalue(values):
    """Your documentation goes here"""    
    x = float(values[0])
    for n in values:
        if n != 'No data':
            if float(n) < x:
                x = float(n)
    return x


def meanvalue(values):
    """Your documentation goes here"""    
    count = 0
    sum = 0
    for item in values:
        if item != 'No data':
            sum += float(item)
            count += 1
    if sum == 0:
        return 0
    else:
        return sum/count


def countvalue(values,xw):
    """Your documentation goes here"""    
    count = 0
    for int in values:
        if int == xw:
            count += 1
    return count


def pixel_neighbours(self, p):
    rows, cols = self.shape
    i, j = p[0], p[1]
    rmin = i - 1 if i - 1 >= 0 else 0
    rmax = i + 1 if i + 1 < rows else i
    cmin = j - 1 if j - 1 >= 0 else 0
    cmax = j + 1 if j + 1 < cols else j
    neighbours = []
    for x in range(rmin, rmax + 1):
        for y in range(cmin, cmax + 1):
            neighbours.append([x,y])
    neighbours.remove([p[0], p[1]])
    return neighbours

def img_to_bin(img):
    binimg = []
    for row in img:
        rowtemp = []
        for pixel in row:
            if pixel[0] >= 125 and pixel[1] >= 125 and pixel[2] >=125:
                rowtemp.append(1)
            else:
                rowtemp.append(0)
        binimg.append(rowtemp)
    binimg = np.array(binimg)
    return(binimg)


def bin_to_img(bin):
    newimg = []
    for row in bin:
        rowtemp = []
        for pixel in row:
            if pixel == 1:
                rowtemp.append([255,255,255])
            else:
                rowtemp.append([0,0,0])
        newimg.append(rowtemp)
    newimg = np.array(newimg)
    return(newimg)


def isodd(num):
    # code logic here
    if num%2 == 0:
        numtype= False
    else:
        numtype = True
    return numtype
