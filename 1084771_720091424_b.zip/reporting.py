
import utils
import numpy as np


"""0 - Harlington, 1 - Marylebone, 2 - Kensington"""
"""0 - no 1- pm10, 2 - pm25"""
"""0 - date, 1- time"""

def median(L):
    L1 = []
    for item in L:
        if item != 'No data':
            L1.append(float(item))
    L1.sort()
    if len(L1) == 0:
        return 0
    if len(L1) == 1:
        return L1[0]
    elif utils.isodd(len(L1)) == True:
        index = int(((len(L1))+1)/2)
        return(L1[index])
    elif utils.isodd(len(L1)) == False:
        index = int(len(L1)/2)
        index1 = int(len(L1)/2 +1)
        return((L1[index-1]+L1[index1-1])/2)

def fill_missing_data(data,newvalue,monitoring_station:str,pollutant:str): 
    """Your documentation goes here"""
    if monitoring_station == 'HRL':
        vmonitoring_station = 0
    elif monitoring_station == 'MY1':
        vmonitoring_station = 1
    elif monitoring_station == 'KC1':
        vmonitoring_station = 2
    if pollutant == 'NO':
        vpollutant = 0
    elif pollutant == 'PM10':
        vpollutant = 1
    elif pollutant == 'PM25':
        vpollutant = 2
    data = open_to_dict(monitoring_station,pollutant,data)#turn it into dictionary
    newdict = {}
    for keys in data:
        listtemp = []
        for value in data[keys]:
            if value !=  'No data':
                listtemp.append(value)
        newdict[keys] = listtemp
    return newdict
    

def open_to_dict(monitoringstationcsv,pollutant,dort):
    #Input monitoringstation, pollutant, date or time type and return a dictionary with corrisponding datas
    monitoringstationcsv = int(monitoringstationcsv) #"""0 - Harlington, 1 - Marylebone, 2 - Kensington"""
    pollutant = int(pollutant)                       #"""0 - no 1- pm10, 2 - pm25"""
    dort = int(dort)                                 #"""0 - date, 1- time"""
    if monitoringstationcsv == 0:           
        file = 'data\Pollution-London Harlington.csv'
    elif monitoringstationcsv == 1:
        file = 'data\Pollution-London Marylebone Road.csv'
    elif monitoringstationcsv == 2:
        file = 'data\Pollution-London N Kensington.csv'
    else:
        raise ValueError("Wrong Folder Input")
    if int(pollutant) > 2:
        raise ValueError("Wrong Pollutant Input")
    if int(dort) > 1:
        raise ValueError("Wrong Date Or Time Input")
    line = open(file).readlines() #open file
    newdict = {}
    for list in line: #iterate through lines
        flist = list.strip().split(',') #remoe /n and make it into list[date,time,no,pm10,pm25]
        if flist[dort] in newdict: #if date/time in newdict,add values to newdict
            newdict[flist[dort]] += '%'+ (flist[int(pollutant) + int(2)])
        else:#if date/time  isnt in newdict,add values to newdict
            newdict[flist[dort]] = flist[int(pollutant) + int(2)]
    newdict.pop('date', None)#remove the heading
    newdict.pop('time', None)#remove the heading
    for values in newdict:
        newdict[values] = newdict[values].split('%')
    return newdict


def daily_average(data,monitoring_station, pollutant):
    """Your documentation goes here"""
    if monitoring_station == 'HRL':
        vmonitoring_station = 0
    elif monitoring_station == 'MY1':
        vmonitoring_station = 1
    elif monitoring_station == 'KC1':
        vmonitoring_station = 2
    if pollutant == 'NO':
        vpollutant = 0
    elif pollutant == 'PM10':
        vpollutant = 1
    elif pollutant == 'PM25':
        vpollutant = 2
    data = fill_missing_data(0,'new_value',vmonitoring_station,vpollutant)#turn it into dictionary
    for key in data:
        data[key] = (round(utils.meanvalue(data[key]),3))#for values in dictionary,calculate their average
        if data[key] == 0:
            data[key] = 'No data'
    return data


def daily_median(data,monitoring_station, pollutant):
    if monitoring_station == 'HRL':
        vmonitoring_station = 0
    elif monitoring_station == 'MY1':
        vmonitoring_station = 1
    elif monitoring_station == 'KC1':
        vmonitoring_station = 2
    if pollutant == 'NO':
        vpollutant = 0
    elif pollutant == 'PM10':
        vpollutant = 1
    elif pollutant == 'PM25':
        vpollutant = 2
    data = fill_missing_data(0,'new_value',vmonitoring_station,vpollutant)#turn it into dictionary
    for key in data:
        data[key] = (round(median(data[key]),3))#for values in dictionary,calculate their median
        if data[key] == 0:
            data[key] = 'No data'
    return data

    
def hourly_average(data,monitoring_station, pollutant):
    if monitoring_station == 'HRL':
        vmonitoring_station = 0
    elif monitoring_station == 'MY1':
        vmonitoring_station = 1
    elif monitoring_station == 'KC1':
        vmonitoring_station = 2
    if pollutant == 'NO':
        vpollutant = 0
    elif pollutant == 'PM10':
        vpollutant = 1
    elif pollutant == 'PM25':
        vpollutant = 2
    data = fill_missing_data(1,'new_value',vmonitoring_station,vpollutant)#turn it into dictionary
    for key in data:
        data[key] = (round(utils.meanvalue(data[key]),3))#for values in dictionary,calculate their mean
        if data[key] == 0:
            data[key] = 'No data'
    return data

    
def monthly_average(data,monitoring_station, pollutant):
    if monitoring_station == 'HRL':
        vmonitoring_station = 0
    elif monitoring_station == 'MY1':
        vmonitoring_station = 1
    elif monitoring_station == 'KC1':
        vmonitoring_station = 2
    if pollutant == 'NO':
        vpollutant = 0
    elif pollutant == 'PM10':
        vpollutant = 1
    elif pollutant == 'PM25':
        vpollutant = 2
    data = daily_average('data',monitoring_station,pollutant)
    newdict = {}
    for keys in data:
        if keys[:7] in newdict:
            if data[keys] != 'No data':
                newdict[keys[:7]] += '%' + str(data[keys])
        else:
            if data[keys] != 'No data':
                newdict[keys[:7]] = str(data[keys])
            else:
                newdict[keys[:7]] = str(0)
    for keys in newdict:
        newdict[keys] = newdict[keys].split('%')
        newdict[keys] = round(utils.meanvalue(newdict[keys]),3)
    for keys in newdict:
        if newdict[keys] == 0:
            newdict[keys] = 'No data'
    return newdict


def peak_hour_date(data, date:str, monitoring_station, pollutant):
    if monitoring_station == 'HRL':
        vmonitoring_station = 0
    elif monitoring_station == 'MY1':
        vmonitoring_station = 1
    elif monitoring_station == 'KC1':
        vmonitoring_station = 2
    if pollutant == 'NO':
        vpollutant = 0
    elif pollutant == 'PM10':
        vpollutant = 1
    elif pollutant == 'PM25':
        vpollutant = 2
    data = fill_missing_data(0,'new_value',vmonitoring_station,vpollutant)#turn it into dictionary
    if date not in data:
        return 'No data or wrong date format(YYYY-MM-DD)'
    keys = date
    max = 0
    for item in data[keys]:
        if float(item) > max:
            max = float(item)
    if max == 0:
        max = 'No data'
    return max


def count_missing_data(data,monitoring_station, pollutant):
    if monitoring_station == 'HRL':
        vmonitoring_station = 0
    elif monitoring_station == 'MY1':
        vmonitoring_station = 1
    elif monitoring_station == 'KC1':
        vmonitoring_station = 2
    if pollutant == 'NO':
        vpollutant = 0
    elif pollutant == 'PM10':
        vpollutant = 1
    elif pollutant == 'PM25':
        vpollutant = 2
    data = open_to_dict(vmonitoring_station,vpollutant,0)#turn it into dictionary
    sum = 0
    for key in data:
        for n in data[key]:
            if n == 'No data':
                sum += 1
    return sum

